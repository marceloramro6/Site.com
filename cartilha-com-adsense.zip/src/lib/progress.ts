import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { PathId } from "./guide-data";

type ProgressState = {
  path: PathId;
  done: Record<string, boolean>;
  setPath: (path: PathId) => void;
  toggle: (id: string) => void;
  reset: () => void;
};

export const useProgress = create<ProgressState>()(
  persist(
    (set) => ({
      path: "vender",
      done: {},
      setPath: (path) => set({ path }),
      toggle: (id) =>
        set((state) => ({
          done: { ...state.done, [id]: !state.done[id] },
        })),
      reset: () => set({ done: {} }),
    }),
    { name: "cartilha-progress" },
  ),
);
