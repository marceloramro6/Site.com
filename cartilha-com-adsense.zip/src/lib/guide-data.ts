export type PathId = "vender" | "conteudo";

export type Niche = {
  id: string;
  label: string;
  rpm: number;
  note: string;
};

export const NICHES: Niche[] = [
  {
    id: "finance",
    label: "Finanças, cartão, crédito",
    rpm: 32,
    note: "Anunciante paga caro. Conteúdo precisa ser cuidadoso e original.",
  },
  {
    id: "insurance",
    label: "Seguro e consórcio",
    rpm: 26,
    note: "Bom RPM, busca constante, texto tem que ser claro.",
  },
  {
    id: "health",
    label: "Saúde e bem-estar",
    rpm: 18,
    note: "Volume alto de busca. Evite milagre e afirmação médica.",
  },
  {
    id: "tech",
    label: "Tecnologia e software",
    rpm: 12,
    note: "Afiliado de ferramenta costuma pagar mais que o banner.",
  },
  {
    id: "edu",
    label: "Concursos e educação",
    rpm: 11,
    note: "Sazonal, mas fiel. Combine com curso afiliado.",
  },
  {
    id: "general",
    label: "Receita, fofoca, meme, notícia",
    rpm: 5,
    note: "Precisa de muito tráfego. Sozinho, quase não paga.",
  },
];

export const PATHS = [
  {
    id: "vender" as const,
    lesson: "01",
    title: "Vender o site",
    kicker: "Dinheiro neste mês",
    summary:
      "Você cobra para criar o site de um negócio local e oferece um plano mensal de manutenção. Um cliente de R$ 2.500 equivale a meses de anúncio.",
    href: "/vender" as const,
  },
  {
    id: "anuncios" as const,
    lesson: "02",
    title: "Meter anúncio",
    kicker: "AdSense e redes",
    summary:
      "O Google cola banners no seu conteúdo. Paga por mil páginas vistas. Só começa a fazer sentido com tráfego de verdade — e nicho certo.",
    href: "/anuncios" as const,
  },
  {
    id: "afiliados" as const,
    lesson: "03",
    title: "Indicar produto",
    kicker: "Afiliados",
    summary:
      "Você recomenda hospedagem, curso, ferramenta ou produto. Cada venda deixa comissão. No mesmo tráfego, costuma pagar mais que banner.",
    href: "/afiliados" as const,
  },
];

export const SELL_PACKAGES = [
  {
    name: "Página única",
    price: "R$ 800 – R$ 2.500",
    items: ["1 página", "botão de WhatsApp", "Google Maps", "celular redondo"],
  },
  {
    name: "Site do negócio",
    price: "R$ 2.500 – R$ 8.000",
    items: ["4 a 6 páginas", "formulário", "SEO básico", "2 rodadas de ajuste"],
  },
  {
    name: "Loja pequena",
    price: "R$ 4.000 – R$ 15.000",
    items: ["catálogo", "pagamento", "frete", "treino de 1 hora"],
  },
];

export const CARE_PLANS = [
  { name: "Manter no ar", price: "R$ 150 – R$ 300/mês", detail: "hospedagem, backup, certificado, um recado no mês" },
  { name: "Cuidado", price: "R$ 300 – R$ 800/mês", detail: "o de cima + textos curtos, Google Meu Negócio, pequenas trocas" },
];

export const OUTREACH_SCRIPT = `Oi, {{nome}}! Vi o Instagram do {{negocio}} e percebi que vocês ainda não têm um site fácil de achar no Google. Eu monto uma página com botão de WhatsApp, endereço e horário, em cerca de uma semana. Posso te mandar 2 exemplos?`;

export type PlanItem = {
  id: string;
  week: number;
  title: string;
  detail: string;
};

export const PLAN: Record<PathId, PlanItem[]> = {
  vender: [
    {
      id: "v-1",
      week: 1,
      title: "Escolher um nicho apertado",
      detail:
        "Salão, dentista, personal, imobiliária, oficina. Um só. Especialista cobra mais e a mensagem fica óbvia.",
    },
    {
      id: "v-2",
      week: 1,
      title: "Montar 3 sites-modelo",
      detail:
        "Três exemplos no nicho, com WhatsApp, mapa e depoimento falso marcado como exemplo. Isso é o portfólio. Sem ele, ninguém compra.",
    },
    {
      id: "v-3",
      week: 1,
      title: "Página sua, com preço",
      detail:
        "Uma página: quem você atende, o que entrega, três pacotes, prazo, forma de pagamento. Preço na cara. Quem esconde preço perde o cliente certo.",
    },
    {
      id: "v-4",
      week: 1,
      title: "Lista de 30 negócios",
      detail:
        "Instagram, Google Maps, caminhada no bairro. Anote quem tem site feio, parado, ou só rede social.",
    },
    {
      id: "v-5",
      week: 2,
      title: "Mandar 10 mensagens por dia",
      detail:
        "Use o texto pronto da lição 01. Personalize o nome e um detalhe real (foto antiga, endereço errado, site fora do ar). Genérico não responde.",
    },
    {
      id: "v-6",
      week: 2,
      title: "Fechar o primeiro, mesmo barato",
      detail:
        "Aceite um preço menor em troca de depoimento com foto e permissão de usar o site no portfólio. O primeiro serve de prova.",
    },
    {
      id: "v-7",
      week: 2,
      title: "Contrato curto + 50% na frente",
      detail:
        "Uma página: o que entra, o que não entra, prazo, revisões (duas), forma de pagamento. Sem isso vira retrabalho eterno.",
    },
    {
      id: "v-8",
      week: 3,
      title: "Entregar e gravar o antes/depois",
      detail:
        "Print do Instagram antigo vs. o site novo. Isso vende o próximo. Peça o depoimento no mesmo dia da entrega.",
    },
    {
      id: "v-9",
      week: 3,
      title: "Vender o plano mensal junto",
      detail:
        "Não entregue a chave e suma. Ofereça manter no ar por R$ 150 a R$ 400. 15 clientes nisso já é um salário.",
    },
    {
      id: "v-10",
      week: 3,
      title: "Pedir indicação com nome",
      detail:
        "“Quem mais no ramo deveria ter um site desses?” Peça o contato. Indicação fecha mais rápido que frio.",
    },
    {
      id: "v-11",
      week: 4,
      title: "Subir o preço do pacote do meio",
      detail:
        "Depois de 2–3 trabalhos, o pacote do meio vira o padrão. O barato fica de isca. O caro existe para fazer o do meio parecer razoável.",
    },
    {
      id: "v-12",
      week: 4,
      title: "Rotina semanal, não disparo",
      detail:
        "Toda segunda: 10 abordagens. Toda sexta: um caso no Instagram. Sem rotina, o mês 2 volta a zero.",
    },
  ],
  conteudo: [
    {
      id: "c-1",
      week: 1,
      title: "Escolher nicho que anunciante paga",
      detail:
        "Finanças, seguro, saúde, software, concurso. Evite meme e fofoca se a meta for anúncio. RPM muda 10x de um tema para o outro.",
    },
    {
      id: "c-2",
      week: 1,
      title: "Lista de 40 perguntas reais",
      detail:
        "O que o povo busca no Google: “melhor X até Y”, “como fazer Z”, “vale a pena W”. Cada pergunta vira um texto. Sem isso você escreve no vazio.",
    },
    {
      id: "c-3",
      week: 1,
      title: "Domínio próprio e páginas de lei",
      detail:
        "Sobre, Contato, Privacidade. AdSense recusa site sem isso. Domínio barato, hospedagem simples. Nada de endereço provisório.",
    },
    {
      id: "c-4",
      week: 1,
      title: "Escrever 10 textos decentes",
      detail:
        "Não é livro. 800 a 1.500 palavras, resposta na primeira tela, título que parece busca. IA pode rascunhar — você revisa com experiência real ou pesquisa.",
    },
    {
      id: "c-5",
      week: 2,
      title: "Estrutura que converte",
      detail:
        "Título, resposta curta, tabela, passo a passo, uma recomendação clara, pergunta frequente. Banner só depois que o texto está em pé.",
    },
    {
      id: "c-6",
      week: 2,
      title: "Cadastrar afiliado do nicho",
      detail:
        "Hotmart, Amazon, hospedagem, ferramenta. Um ou dois programas, não quinze. Link no meio do texto, com contexto, não escondido.",
    },
    {
      id: "c-7",
      week: 2,
      title: "Pedir o AdSense só então",
      detail:
        "Com ~15 textos, páginas legais e domínio. Se recusar, leia o motivo, corrija, espere. Não encha o site de anúncio inventado.",
    },
    {
      id: "c-8",
      week: 3,
      title: "Publicar 3 vezes por semana",
      detail:
        "Ritmo vence talentoso irregular. Um texto bem feito, interno, com link para outro texto seu. Google gosta de site vivo.",
    },
    {
      id: "c-9",
      week: 3,
      title: "Olhar Search Console",
      detail:
        "Ver o que já aparece, mesmo em posição 40. Reescrever esses. É mais barato melhorar o que o Google já viu do que inventar tema novo.",
    },
    {
      id: "c-10",
      week: 3,
      title: "Uma página de oferta",
      detail:
        "Além do banner: um guia em PDF, uma consultoria curta, ou o seu serviço de fazer sites. O site de conteúdo também pode vender serviço.",
    },
    {
      id: "c-11",
      week: 4,
      title: "Matar o que não traz visita",
      detail:
        "Textos que ninguém abre: junta, redireciona ou reescreve. Site inchado de IA genérica é o que o AdSense anda recusando.",
    },
    {
      id: "c-12",
      week: 4,
      title: "Meta de 6 meses, não de 6 dias",
      detail:
        "Anúncio de verdade pede tráfego. Enquanto o Google não manda gente, o plano B é vender um site por semana com o que você já sabe fazer.",
    },
  ],
};

export const ADSENSE_CHECKS = [
  { id: "a-domain", label: "Domínio próprio no ar (não endereço provisório)" },
  { id: "a-about", label: "Página Sobre com nome e o que o site faz" },
  { id: "a-contact", label: "Página Contato com e-mail verdadeiro" },
  { id: "a-privacy", label: "Política de privacidade" },
  { id: "a-posts", label: "Pelo menos 15 textos originais, úteis, revisados" },
  { id: "a-nav", label: "Menu claro, não um emaranhado de páginas vazias" },
  { id: "a-ads", label: "Nenhum anúncio inventado ou rede duvidosa antes da aprovação" },
];

export const AFFILIATE_PROGRAMS = [
  {
    name: "Hotmart, Eduzz, Monetizze",
    fit: "Curso, mentoria, infoproduto",
    cut: "20% a 50%+ por venda",
  },
  {
    name: "Amazon Associados",
    fit: "Produto físico que você realmente usa no texto",
    cut: "alguns % por categoria",
  },
  {
    name: "Mercado Livre / Shopee",
    fit: "Review de coisa que o brasileiro busca para comprar",
    cut: "varia por item",
  },
  {
    name: "Hospedagem (Hostinger, HostGator…)",
    fit: "Tutorial de “como subir um site”",
    cut: "valor fixo por venda, às vezes recorrente",
  },
  {
    name: "Ferramenta / SaaS",
    fit: "Texto de “melhor X para Y”",
    cut: "20% a 40%, muitas vezes todo mês",
  },
];
