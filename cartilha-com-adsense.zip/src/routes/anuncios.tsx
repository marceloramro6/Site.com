import { createFileRoute, Link } from "@tanstack/react-router";
import { AdsCalculator } from "@/components/ads-calculator";
import { Checklist } from "@/components/checklist";
import { LessonLayout, Section } from "@/components/lesson-layout";
import { Button } from "@/components/ui/button";
import { ADSENSE_CHECKS } from "@/lib/guide-data";

export const Route = createFileRoute("/anuncios")({ component: AdsPage });

function AdsPage() {
  return (
    <LessonLayout
      lesson="02"
      kicker="AdSense"
      title="Meter anúncio no site"
      lead="Dá para colar banner, sim. Só que anúncio paga por mil páginas vistas — e no Brasil o milheiro é barato, a menos que o tema seja caro para anunciante."
    >
      <AdsCalculator />

      <Section title="Como o AdSense funciona">
        <ol className="list-decimal space-y-2 pl-5">
          <li>Você publica conteúdo original em domínio próprio.</li>
          <li>
            Pede aprovação no Google AdSense. Eles olham se o site parece um
            site de verdade, não um molde vazio.
          </li>
          <li>Se passar, um código cola anúncios nas páginas.</li>
          <li>
            O dinheiro pinga por clique e por milheiro. Saque mínimo: 100
            dólares. Até lá, fica parado.
          </li>
        </ol>
        <p>
          Em 2026 o Google está mais chato com site feito 100% de texto genérico
          de IA. Revisar, ter opinião, ter página de gente: isso não é
          enfeite, é filtro.
        </p>
      </Section>

      <Section title="Quando vale a pena">
        <p>
          Vale se você topa escrever (ou editar) por meses, num tema em que
          banco, plano de saúde ou software anunciam. Não vale se a ideia é
          “subo amanhã e o Google paga o aluguel”.
        </p>
        <p>
          Banner no site de serviço (o site que vende o seu trabalho) quase
          sempre atrapalha. Ali o visitante tem que clicar em “pedir orçamento”,
          não num cartão de crédito aleatório.
        </p>
      </Section>

      <Section title="Lista antes de pedir o AdSense">
        <p>Marca o que já está pronto. Fica salvo neste aparelho.</p>
        <Checklist items={ADSENSE_CHECKS} />
      </Section>

      <Section title="Onde colar o anúncio (depois de aprovado)">
        <ul className="space-y-2">
          <li>Depois do segundo parágrafo — o leitor já entrou no texto.</li>
          <li>No fim, junto da recomendação. Nunca em cima do título.</li>
          <li>Um ou dois por tela no celular. Mais que isso, o Google corta e o leitor foge.</li>
        </ul>
        <p>
          Quando o tráfego crescer, dá para trocar o AdSense por rede que paga
          mais (Ezoic, depois Mediavine). Isso é problema bom. Primeiro precisa
          de visita.
        </p>
      </Section>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Button asChild>
          <Link to="/afiliados">Afiliado paga mais no mesmo tráfego</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/plano">Ir para o plano</Link>
        </Button>
      </div>
    </LessonLayout>
  );
}
