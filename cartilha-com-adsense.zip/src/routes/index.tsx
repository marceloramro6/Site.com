import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PATHS } from "@/lib/guide-data";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main>
      <section className="mx-auto max-w-5xl px-5 py-12 pl-7 md:px-5 md:py-20">
        <p className="text-xs font-medium tracking-[0.18em] text-accent uppercase">
          Lição 00 · o mapa
        </p>
        <h1 className="mt-4 max-w-3xl font-display text-[2.4rem] leading-[1.12] font-medium text-ink md:text-6xl">
          Um site vazio não paga nada.{" "}
          <em className="italic text-accent">Um site com caminho, paga.</em>
        </h1>
        <p className="mt-5 max-w-xl text-lg text-muted">
          Três jeitos, sem enrolação: vender o site para alguém, colocar anúncio,
          ou indicar produto. Você escolhe um, segue as instruções, marca o que
          já fez.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button asChild size="lg">
            <Link to="/plano">
              Abrir o plano de 30 dias
              <ArrowRight className="size-4" strokeWidth={1.75} />
            </Link>
          </Button>
          <Button asChild variant="secondary" size="lg">
            <Link to="/anuncios">Calcular anúncio</Link>
          </Button>
        </div>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-5xl gap-px bg-line md:grid-cols-3">
          {PATHS.map((path) => (
            <Link
              key={path.id}
              to={path.href}
              className="group flex flex-col bg-surface px-6 py-8 pl-7 transition-colors duration-150 hover:bg-tint md:pl-8"
            >
              <span className="font-display text-sm text-accent">{path.lesson}</span>
              <span className="mt-3 text-xs font-medium tracking-[0.16em] text-muted uppercase">
                {path.kicker}
              </span>
              <h2 className="mt-2 font-display text-2xl font-medium text-ink">{path.title}</h2>
              <p className="mt-3 flex-1 text-[0.98rem] leading-relaxed text-muted">
                {path.summary}
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-accent">
                Ler a lição
                <ArrowRight
                  className="size-4 transition-transform duration-150 group-hover:translate-x-0.5"
                  strokeWidth={1.75}
                />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-14 pl-7 md:px-5">
        <h2 className="font-display text-3xl font-medium text-ink">Qual caminho primeiro</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <article className="rounded-xl border border-line bg-surface p-6">
            <p className="text-xs font-medium tracking-[0.16em] text-accent uppercase">
              Se precisa de dinheiro agora
            </p>
            <h3 className="mt-2 font-display text-xl text-ink">Venda o site</h3>
            <p className="mt-2 text-muted">
              Um dentista, um salão, uma oficina. Você entrega em uma semana e
              cobra à vista. Anúncio não substitui isso no começo.
            </p>
          </article>
          <article className="rounded-xl border border-line bg-surface p-6">
            <p className="text-xs font-medium tracking-[0.16em] text-accent uppercase">
              Se aguenta construir
            </p>
            <h3 className="mt-2 font-display text-xl text-ink">Conteúdo + afiliado + banner</h3>
            <p className="mt-2 text-muted">
              Escreve para quem busca no Google. Afiliado paga o almoço.
              Banner é o troco. Leva meses. Escala melhor.
            </p>
          </article>
        </div>

        <dl className="mt-10 grid gap-6 border-t border-line pt-10 sm:grid-cols-3">
          <div>
            <dt className="text-xs font-medium tracking-wide text-muted uppercase">
              1 site institucional
            </dt>
            <dd className="mt-1 font-display text-3xl text-ink">R$ 2.500+</dd>
            <p className="mt-1 text-sm text-muted">no Brasil, pacote comum de 2026</p>
          </div>
          <div>
            <dt className="text-xs font-medium tracking-wide text-muted uppercase">
              Banner, nicho fraco
            </dt>
            <dd className="mt-1 font-display text-3xl text-ink">R$ 50</dd>
            <p className="mt-1 text-sm text-muted">com 10 mil visitas de meme ou fofoca</p>
          </div>
          <div>
            <dt className="text-xs font-medium tracking-wide text-muted uppercase">
              20 planos mensais
            </dt>
            <dd className="mt-1 font-display text-3xl text-ink">R$ 6.000</dd>
            <p className="mt-1 text-sm text-muted">recorrente, antes do próximo projeto</p>
          </div>
        </dl>
      </section>
    </main>
  );
}
