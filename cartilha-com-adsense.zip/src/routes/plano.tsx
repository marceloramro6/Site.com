import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { LessonLayout } from "@/components/lesson-layout";
import { Button } from "@/components/ui/button";
import { PLAN, type PathId } from "@/lib/guide-data";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/plano")({ component: PlanoPage });

const PATH_LABEL: Record<PathId, { title: string; blurb: string }> = {
  vender: {
    title: "Vender sites",
    blurb: "Cliente local, pacote fechado, plano mensal.",
  },
  conteudo: {
    title: "Conteúdo + anúncio + afiliado",
    blurb: "Textos, Google, comissão, banner por último.",
  },
};

function PlanoPage() {
  const path = useProgress((s) => s.path);
  const setPath = useProgress((s) => s.setPath);
  const done = useProgress((s) => s.done);
  const toggle = useProgress((s) => s.toggle);
  const reset = useProgress((s) => s.reset);

  const items = PLAN[path];
  const total = items.length;
  const complete = items.filter((i) => done[i.id]).length;
  const weeks = [1, 2, 3, 4] as const;

  return (
    <LessonLayout
      lesson="04"
      kicker="rotina"
      title="30 dias, uma lista"
      lead="Escolhe o caminho. Marca o que já fez. Não precisa de aplicativo nenhum — só de não fingir que “depois eu vejo”."
    >
      <div className="grid gap-3 sm:grid-cols-2">
        {(Object.keys(PATH_LABEL) as PathId[]).map((id) => {
          const active = path === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setPath(id)}
              className={cn(
                "rounded-xl border px-4 py-4 text-left transition-colors duration-150",
                active
                  ? "border-accent bg-tint"
                  : "border-line bg-surface hover:bg-bg",
              )}
            >
              <p className="font-display text-lg text-ink">{PATH_LABEL[id].title}</p>
              <p className="mt-1 text-sm text-muted">{PATH_LABEL[id].blurb}</p>
            </button>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
        <p className="text-sm text-muted">
          <span className="font-display text-2xl tabular-nums text-ink">{complete}</span>
          <span className="mx-1">/</span>
          <span className="tabular-nums">{total}</span> feitas neste caminho
        </p>
        <Button type="button" variant="ghost" size="sm" onClick={reset}>
          Limpar marcas
        </Button>
      </div>

      <div
        className="h-1.5 overflow-hidden rounded-full bg-line"
        role="progressbar"
        aria-valuenow={complete}
        aria-valuemin={0}
        aria-valuemax={total}
      >
        <div
          className="h-full bg-accent transition-[width] duration-200"
          style={{ width: `${total === 0 ? 0 : (complete / total) * 100}%` }}
        />
      </div>

      {weeks.map((week) => (
        <section key={week} className="space-y-3">
          <h2 className="font-display text-xl text-ink">Semana {week}</h2>
          <ul className="space-y-2">
            {items
              .filter((i) => i.week === week)
              .map((item) => {
                const on = Boolean(done[item.id]);
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => toggle(item.id)}
                      className={cn(
                        "flex w-full gap-3 rounded-xl border px-4 py-4 text-left transition-colors duration-150",
                        on ? "border-accent/40 bg-tint" : "border-line bg-surface",
                      )}
                    >
                      <span
                        className={cn(
                          "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-md border",
                          on
                            ? "border-accent bg-accent text-accent-fg"
                            : "border-line bg-bg text-transparent",
                        )}
                        aria-hidden
                      >
                        <Check className="size-3.5" strokeWidth={2.4} />
                      </span>
                      <span>
                        <span className={cn("block font-medium text-ink", on && "text-muted")}>
                          {item.title}
                        </span>
                        <span className="mt-1 block text-sm leading-relaxed text-muted">
                          {item.detail}
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })}
          </ul>
        </section>
      ))}
    </LessonLayout>
  );
}
