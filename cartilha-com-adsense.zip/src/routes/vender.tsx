import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { LessonLayout, Section } from "@/components/lesson-layout";
import { Button } from "@/components/ui/button";
import { CARE_PLANS, OUTREACH_SCRIPT, SELL_PACKAGES } from "@/lib/guide-data";

export const Route = createFileRoute("/vender")({ component: VenderPage });

function VenderPage() {
  return (
    <LessonLayout
      lesson="01"
      kicker="serviço"
      title="Vender o site"
      lead="O jeito mais rápido de um site virar dinheiro: alguém te paga para fazer o dele. Anúncio espera visita. Cliente paga na entrega."
    >
      <Section title="O que você está vendendo, de verdade">
        <p>
          Não é código. É um endereço na internet que manda gente no WhatsApp,
          no mapa e no telefone. Dono de salão não quer “React”. Quer o cliente
          achar o horário e clicar em conversar.
        </p>
        <p>
          Por isso o pacote tem que ser óbvio: páginas, prazo, o que entra, o
          que não entra, e um valor mensal para não cair depois que você some.
        </p>
      </Section>

      <Section title="Quanto cobrar (2026, Brasil)">
        <div className="overflow-x-auto rounded-xl border border-line">
          <table className="w-full min-w-[32rem] text-left text-sm">
            <thead className="bg-tint text-xs tracking-wide text-muted uppercase">
              <tr>
                <th className="px-4 py-3 font-medium">Pacote</th>
                <th className="px-4 py-3 font-medium">Faixa</th>
                <th className="px-4 py-3 font-medium">O que entrega</th>
              </tr>
            </thead>
            <tbody className="bg-surface">
              {SELL_PACKAGES.map((row) => (
                <tr key={row.name} className="border-t border-line">
                  <td className="px-4 py-3 font-medium text-ink">{row.name}</td>
                  <td className="px-4 py-3 tabular-nums">{row.price}</td>
                  <td className="px-4 py-3 text-muted">{row.items.join(" · ")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p>
          Cobre por projeto, nunca por hora. Hora assusta o cliente e te pune
          por ficar mais rápido. 50% na assinatura, 50% na entrega. Duas
          rodadas de ajuste. O resto é extra.
        </p>
      </Section>

      <Section title="O ouro: o plano mensal">
        <ul className="space-y-3">
          {CARE_PLANS.map((plan) => (
            <li key={plan.name} className="rounded-lg border border-line bg-surface px-4 py-3">
              <p className="font-medium text-ink">
                {plan.name}{" "}
                <span className="font-sans text-sm font-normal text-muted">· {plan.price}</span>
              </p>
              <p className="text-sm text-muted">{plan.detail}</p>
            </li>
          ))}
        </ul>
        <p>
          Quinze clientes a R$ 300 são R$ 4.500 todo mês, com pouco trabalho.
          Sem isso você vive caçando projeto novo como se fosse o primeiro dia.
        </p>
      </Section>

      <Section title="Como achar o primeiro cliente">
        <ol className="list-decimal space-y-2 pl-5">
          <li>Três sites-modelo no mesmo nicho. Sem isso, a conversa morre.</li>
          <li>
            Google Maps e Instagram: negócio com foto bonita e site feio, ou
            site nenhum.
          </li>
          <li>Mensagem curta, com um detalhe real do negócio deles.</li>
          <li>Mostre o modelo no celular, na hora. Não mande PDF de 20 páginas.</li>
        </ol>
        <p>
          Plataforma (99Freelas, Workana, Fiverr) serve para treinar. Elas
          comem taxa e empurram preço para baixo. O alvo é cliente direto.
        </p>
      </Section>

      <OutreachCard />

      <Section title="Não faça isso">
        <ul className="space-y-2">
          <li>Trabalhar de graça “para portfólio” depois do segundo job.</li>
          <li>Aceitar “meus amigos vão ver e te contratar” como pagamento.</li>
          <li>Começar sem 50% na conta. Retrabalho adora cliente que não pagou.</li>
          <li>Entregar o site e não oferecer o plano. Você está jogando renda fora.</li>
        </ul>
      </Section>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Button asChild>
          <Link to="/plano">Marcar no plano de 30 dias</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/anuncios">E os anúncios?</Link>
        </Button>
      </div>
    </LessonLayout>
  );
}

function OutreachCard() {
  const [copied, setCopied] = useState(false);
  const text = OUTREACH_SCRIPT.replaceAll("{{nome}}", "Maria").replaceAll(
    "{{negocio}}",
    "Studio Luna",
  );

  async function copy() {
    try {
      await navigator.clipboard.writeText(OUTREACH_SCRIPT);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <aside className="rounded-xl border border-line bg-surface p-5 md:p-6">
      <p className="text-xs font-medium tracking-[0.16em] text-accent uppercase">
        Texto pronto
      </p>
      <h2 className="mt-2 font-display text-xl text-ink">Mensagem de WhatsApp</h2>
      <p className="mt-2 text-sm text-muted">
        Troque os nomes. Um detalhe específico vale mais que dez elogios.
      </p>
      <blockquote className="mt-4 rounded-lg bg-bg px-4 py-3 text-[0.98rem] leading-relaxed text-ink">
        {text}
      </blockquote>
      <Button type="button" variant="secondary" className="mt-4" onClick={copy}>
        {copied ? (
          <>
            <Check className="size-4" strokeWidth={1.75} />
            Copiado
          </>
        ) : (
          <>
            <Copy className="size-4" strokeWidth={1.75} />
            Copiar com os marcadores
          </>
        )}
      </Button>
    </aside>
  );
}
