import { createFileRoute, Link } from "@tanstack/react-router";
import { LessonLayout, Section } from "@/components/lesson-layout";
import { Button } from "@/components/ui/button";
import { AFFILIATE_PROGRAMS } from "@/lib/guide-data";

export const Route = createFileRoute("/afiliados")({ component: AfiliadosPage });

function AfiliadosPage() {
  return (
    <LessonLayout
      lesson="03"
      kicker="indicação"
      title="Indicar produto"
      lead="Você recomenda algo que o texto já estava prestes a recomendar. A pessoa compra no link. Você ganha um pedaço. Sem estoque, sem suporte, sem inventar produto no dia 1."
    >
      <Section title="Por que isso ganha de banner">
        <p>
          Banner paga milheiro. Afiliado paga intenção. Um texto “melhor
          hospedagem para loja” com 5 mil visitas pode fazer R$ 80 de AdSense e
          R$ 800 de comissão — no mesmo mês, no mesmo artigo.
        </p>
        <p>
          A regra: o link tem que ser a resposta da pergunta, não um adesivo no
          canto. “Eu uso X porque Y. Aqui o link.” Ponto.
        </p>
      </Section>

      <Section title="Onde se cadastrar">
        <div className="overflow-x-auto rounded-xl border border-line">
          <table className="w-full min-w-[30rem] text-left text-sm">
            <thead className="bg-tint text-xs tracking-wide text-muted uppercase">
              <tr>
                <th className="px-4 py-3 font-medium">Programa</th>
                <th className="px-4 py-3 font-medium">Encaixa em</th>
                <th className="px-4 py-3 font-medium">Corte típico</th>
              </tr>
            </thead>
            <tbody className="bg-surface">
              {AFFILIATE_PROGRAMS.map((row) => (
                <tr key={row.name} className="border-t border-line">
                  <td className="px-4 py-3 font-medium text-ink">{row.name}</td>
                  <td className="px-4 py-3 text-muted">{row.fit}</td>
                  <td className="px-4 py-3">{row.cut}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      <Section title="Como escrever um texto que vende sem parecer golpe">
        <ol className="list-decimal space-y-2 pl-5">
          <li>Título = a busca. “Melhor X para Y em 2026”, “Vale a pena Z?”.</li>
          <li>Resposta na primeira tela. Não esconda o veredito no parágrafo 14.</li>
          <li>Uma tabela honesta: preço, para quem serve, defeito real.</li>
          <li>Um recado “eu indicaria / não indicaria porque”. Opinião é o filtro do Google e do leitor.</li>
          <li>O link uma vez no meio, outra no fim. Sem pop-up, sem mentira de “último dia”.</li>
        </ol>
      </Section>

      <Section title="Combo que funciona">
        <p>
          Conteúdo que o Google manda gente → afiliado no meio → banner no resto
          → e, se couber, o seu serviço de fazer sites como oferta própria.
        </p>
        <p>
          Site de conteúdo não está proibido de vender serviço. Muita gente
          lê “como ter um site” e prefere pagar alguém. Essa pessoa é cliente da
          lição 01.
        </p>
      </Section>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Button asChild>
          <Link to="/plano">Montar a rotina de 30 dias</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/vender">Voltar para vender o site</Link>
        </Button>
      </div>
    </LessonLayout>
  );
}
