import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/vender" as const, label: "Vender" },
  { to: "/anuncios" as const, label: "Anúncios" },
  { to: "/afiliados" as const, label: "Afiliados" },
  { to: "/plano" as const, label: "Plano 30 dias" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/92 backdrop-blur-sm">
      <div className="mx-auto flex h-14 max-w-5xl items-center justify-between gap-4 px-5 pl-7 md:h-16 md:pl-5">
        <Link to="/" className="flex items-baseline gap-2" onClick={() => setOpen(false)}>
          <span className="font-display text-lg font-semibold tracking-tight text-ink md:text-xl">
            Cartilha
          </span>
          <span className="hidden text-xs text-muted sm:inline">site que paga</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Seções">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-[10px] px-3 py-2 text-sm text-muted transition-colors duration-150 hover:bg-surface hover:text-ink"
              activeProps={{ className: "bg-tint text-ink" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-[10px] text-ink md:hidden"
          aria-expanded={open}
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" strokeWidth={1.75} /> : <Menu className="size-5" strokeWidth={1.75} />}
        </button>
      </div>

      <div
        className={cn(
          "border-t border-line bg-bg md:hidden",
          open ? "block" : "hidden",
        )}
      >
        <nav className="flex flex-col px-5 py-3" aria-label="Menu móvel">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex min-h-11 items-center rounded-[10px] px-3 text-base text-ink"
              activeProps={{ className: "bg-tint" }}
              onClick={() => setOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
