export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-line">
      <div className="mx-auto flex max-w-5xl flex-col gap-2 px-5 py-8 pl-7 text-sm text-muted md:flex-row md:items-center md:justify-between md:pl-5">
        <p className="font-display text-ink">Cartilha</p>
        <p>
          Números de 2026, em média. Não é garantia — é ponto de partida para
          não trabalhar no escuro.
        </p>
      </div>
    </footer>
  );
}
