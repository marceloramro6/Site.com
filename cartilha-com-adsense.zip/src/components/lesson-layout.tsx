import type { ReactNode } from "react";

type LessonLayoutProps = {
  lesson: string;
  kicker?: string;
  title: string;
  lead: string;
  children: ReactNode;
};

export function LessonLayout({
  lesson,
  kicker,
  title,
  lead,
  children,
}: LessonLayoutProps) {
  return (
    <main className="mx-auto w-full max-w-3xl px-5 py-10 pl-7 md:px-5 md:py-16">
      <p className="font-sans text-xs font-medium tracking-[0.18em] text-accent uppercase">
        Lição {lesson}
        {kicker ? ` · ${kicker}` : ""}
      </p>
      <h1 className="mt-3 font-display text-4xl font-medium text-ink md:text-5xl">{title}</h1>
      <p className="mt-4 max-w-prose text-lg text-muted">{lead}</p>
      <div className="mt-10 space-y-12">{children}</div>
    </main>
  );
}

export function Section({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <section className="space-y-4">
      <h2 className="font-display text-2xl font-medium text-ink">{title}</h2>
      <div className="space-y-3 text-[1.05rem] leading-relaxed text-ink/90">{children}</div>
    </section>
  );
}
