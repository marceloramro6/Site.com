import * as Slider from "@radix-ui/react-slider";
import { useMemo, useState } from "react";
import { NICHES } from "@/lib/guide-data";
import { formatBrl, formatInt } from "@/lib/utils";

export function AdsCalculator() {
  const [views, setViews] = useState(20000);
  const [nicheId, setNicheId] = useState(NICHES[3].id);

  const niche = NICHES.find((n) => n.id === nicheId) ?? NICHES[3];
  const adsense = useMemo(() => (views / 1000) * niche.rpm, [views, niche.rpm]);
  const affiliate = adsense * 6;
  const oneSite = 2500;
  const monthsForSite = Math.max(1, Math.round(oneSite / Math.max(adsense, 1)));
  const viewsForThousand = Math.ceil((1000 / niche.rpm) * 1000);

  return (
    <div className="rounded-xl border border-line bg-surface p-5 shadow-card md:p-7">
      <p className="text-xs font-medium tracking-[0.16em] text-accent uppercase">
        Calculadora
      </p>
      <h2 className="mt-2 font-display text-2xl font-medium text-ink">
        Quanto o anúncio paga de verdade
      </h2>
      <p className="mt-2 text-muted">
        Arraste as visitas e escolha o tema. O valor é uma média de 2026 no
        Brasil — não uma promessa.
      </p>

      <label className="mt-6 block text-sm font-medium text-ink" htmlFor="niche">
        Tema do site
      </label>
      <select
        id="niche"
        value={nicheId}
        onChange={(e) => setNicheId(e.target.value)}
        className="mt-2 h-11 w-full rounded-[10px] border border-line bg-bg px-3 text-ink"
      >
        {NICHES.map((n) => (
          <option key={n.id} value={n.id}>
            {n.label} · cerca de {formatBrl(n.rpm)} / mil páginas
          </option>
        ))}
      </select>
      <p className="mt-2 text-sm text-muted">{niche.note}</p>

      <div className="mt-6 flex items-end justify-between gap-3">
        <label className="text-sm font-medium text-ink" htmlFor="views">
          Páginas vistas por mês
        </label>
        <span className="font-display text-xl tabular-nums text-ink">
          {formatInt(views)}
        </span>
      </div>
      <Slider.Root
        id="views"
        className="relative mt-4 flex h-11 w-full touch-none items-center"
        value={[views]}
        min={1000}
        max={200000}
        step={1000}
        onValueChange={(v) => setViews(v[0] ?? 1000)}
      >
        <Slider.Track className="relative h-1.5 grow rounded-full bg-line">
          <Slider.Range className="absolute h-full rounded-full bg-accent" />
        </Slider.Track>
        <Slider.Thumb
          className="block size-5 rounded-full border border-accent bg-surface shadow-card focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          aria-label="Páginas vistas"
        />
      </Slider.Root>

      <dl className="mt-8 grid gap-3 sm:grid-cols-3">
        <Stat label="Só AdSense" value={formatBrl(adsense)} hint="banner no texto" />
        <Stat
          label="Com afiliado no mesmo tráfego"
          value={formatBrl(affiliate)}
          hint="cerca de 6×, se o texto vender"
        />
        <Stat
          label="Um site vendido"
          value={formatBrl(oneSite)}
          hint={`equivale a ~${monthsForSite} ${monthsForSite === 1 ? "mês" : "meses"} de anúncio`}
        />
      </dl>

      <p className="mt-6 border-t border-line pt-4 text-sm text-muted">
        Para fazer {formatBrl(1000)}/mês só de banner neste tema, você precisa de
        cerca de{" "}
        <strong className="font-medium text-ink">{formatInt(viewsForThousand)}</strong>{" "}
        páginas vistas. Por isso anúncio é o último ingrediente, não o primeiro.
      </p>
    </div>
  );
}

function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="rounded-lg bg-bg px-4 py-4">
      <dt className="text-xs font-medium tracking-wide text-muted uppercase">{label}</dt>
      <dd className="mt-1 font-display text-2xl tabular-nums text-ink">{value}</dd>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </div>
  );
}
