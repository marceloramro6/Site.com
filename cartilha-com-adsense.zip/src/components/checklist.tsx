import { Check } from "lucide-react";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/utils";

export function Checklist({
  items,
}: {
  items: { id: string; label: string }[];
}) {
  const done = useProgress((s) => s.done);
  const toggle = useProgress((s) => s.toggle);

  return (
    <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
      {items.map((item) => {
        const on = Boolean(done[item.id]);
        return (
          <li key={item.id}>
            <button
              type="button"
              onClick={() => toggle(item.id)}
              className="flex w-full min-h-14 items-start gap-3 px-4 py-3 text-left"
            >
              <span
                className={cn(
                  "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-md border",
                  on
                    ? "border-accent bg-accent text-accent-fg"
                    : "border-line bg-bg text-transparent",
                )}
                aria-hidden
              >
                <Check className="size-3.5" strokeWidth={2.4} />
              </span>
              <span className={cn("text-[1.02rem] leading-snug", on && "text-muted line-through")}>
                {item.label}
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}
